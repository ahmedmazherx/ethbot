require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const { Web3 } = require('web3');
const { MongoClient } = require('mongodb');
const axios = require('axios');
const { S3Client, PutObjectCommand, GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");

const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: true });
const web3 = new Web3(`https://mainnet.infura.io/v3/${process.env.INFURA_PROJECT_ID}`);

const username = encodeURIComponent(process.env.MONGODB_USERNAME);
const password = encodeURIComponent(process.env.MONGODB_PASSWORD);
const cluster = process.env.MONGODB_CLUSTER;

const mongoUrl = `mongodb+srv://${username}:${password}@${cluster}/?retryWrites=true&w=majority&appName=Cluster0`;
const dbName = 'ethPaymentBot';
let db;

const PAYMENT_ADDRESS = '0x6ED2eD2F6047FEAF6631d8AF08791cA4eB27a7d2';

const userState = {};

const blockchains = [
    { name: "Bitcoin", symbol: "BTC" }, { name: "Ethereum", symbol: "ETH" },
    { name: "Binance Smart Chain", symbol: "BNB" }, { name: "Cardano", symbol: "ADA" },
    { name: "Solana", symbol: "SOL" }, { name: "Ripple", symbol: "XRP" },
    { name: "Polkadot", symbol: "DOT" }, { name: "Dogecoin", symbol: "DOGE" },
    { name: "Litecoin", symbol: "LTC" }, { name: "Chainlink", symbol: "LINK" },
    { name: "Stellar", symbol: "XLM" }, { name: "Uniswap", symbol: "UNI" },
    { name: "Avalanche", symbol: "AVAX" }, { name: "Terra", symbol: "LUNA" },
    { name: "VeChain", symbol: "VET" }, { name: "Tron", symbol: "TRX" },
    { name: "Tezos", symbol: "XTZ" }, { name: "EOS", symbol: "EOS" },
    { name: "Monero", symbol: "XMR" }, { name: "Algorand", symbol: "ALGO" }
];

const s3Client = new S3Client({
    region: process.env.AWS_REGION,
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    },
});

async function connectToMongoDB() {
    try {
        const client = new MongoClient(mongoUrl);
        await client.connect();
        console.log("Connected successfully to MongoDB");
        db = client.db(dbName);
        return client;
    } catch (error) {
        console.error("Could not connect to MongoDB", error);
        process.exit(1);
    }
}

function startProcess(chatId) {
    userState[chatId] = { step: 1 };
    
    const keyboard = blockchains.map(blockchain => [blockchain.name]);
    const options = {
        reply_markup: {
            keyboard: keyboard,
            one_time_keyboard: true,
        },
    };
    
    bot.sendMessage(chatId, 'Welcome! Please select a blockchain:', options);
}

bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    startProcess(chatId);
});

bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;

    if (text === '/start') {
        return; // The /start command is handled separately
    }

    if (text === "Transaction Approved") {
        bot.sendMessage(chatId, "Your last transaction was approved. You can start a new process by sending /start");
        return;
    }

    if (!userState[chatId] || !userState[chatId].step) {
        startProcess(chatId);
        return;
    }

    switch (userState[chatId].step) {
        case 1:
            handleBlockchainSelection(chatId, text);
            break;
        case 2:
            handleName(chatId, text);
            break;
        case 3:
            handleContactAddress(chatId, text);
            break;
        case 4:
            handleEmail(chatId, text);
            break;
        case 5:
            await handleImage(chatId, msg);
            break;
        case 6:
            handleWebsite(chatId, text);
            break;
        case 7:
            handlePayment(chatId, text);
            break;
    }
});

function handleBlockchainSelection(chatId, blockchain) {
    if (!blockchains.some(b => b.name === blockchain)) {
        bot.sendMessage(chatId, 'Please select a valid blockchain from the list.');
        return;
    }
    userState[chatId].blockchain = blockchain;
    userState[chatId].step = 2;
    bot.sendMessage(chatId, 'Please enter your name:');
}

function handleName(chatId, name) {
    userState[chatId].name = name;
    userState[chatId].step = 3;
    bot.sendMessage(chatId, 'Please enter your contact address:');
}

async function handleContactAddress(chatId, contactAddress) {
    // Check if contact address already exists in the database
    const existingUser = await db.collection('users').findOne({ contactAddress });
    if (existingUser) {
        bot.sendMessage(chatId, 'This contact address is already used. Please submit a new one.');
        return;
    }
    
    userState[chatId].contactAddress = contactAddress;
    userState[chatId].step = 4;
    bot.sendMessage(chatId, 'Please enter your email:');
}

function handleEmail(chatId, email) {
    userState[chatId].email = email;
    userState[chatId].step = 5;
    bot.sendMessage(chatId, 'Please upload an image:');
}

async function handleImage(chatId, msg) {
    if (!msg.photo || msg.photo.length === 0) {
        bot.sendMessage(chatId, 'Please upload a valid image.');
        return;
    }

    const fileId = msg.photo[msg.photo.length - 1].file_id;
    const fileLink = await bot.getFileLink(fileId);

    try {
        const response = await axios.get(fileLink, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data, 'binary');

        const params = {
            Bucket: process.env.AWS_BUCKET_NAME,
            Key: `${chatId}_${Date.now()}.jpg`,
            Body: buffer,
            ContentType: 'image/jpeg'
        };

        const command = new PutObjectCommand(params);
        await s3Client.send(command);

        const getObjectParams = {
            Bucket: process.env.AWS_BUCKET_NAME,
            Key: params.Key,
        };
        const getCommand = new GetObjectCommand(getObjectParams);
        const url = await getSignedUrl(s3Client, getCommand, { expiresIn: 3600 });

        userState[chatId].imageUrl = url;
        userState[chatId].step = 6;
        bot.sendMessage(chatId, 'Image uploaded successfully. Please enter your website link:');
    } catch (error) {
        console.error('Error uploading image:', error);
        bot.sendMessage(chatId, 'Failed to upload image. Please try again.');
    }
}

function handleWebsite(chatId, website) {
    userState[chatId].website = website;
    userState[chatId].step = 7;
    bot.sendMessage(chatId, `Please send exactly 0.003 ETH to the following address:\n${PAYMENT_ADDRESS}\n\nOnce you've made the payment, please provide the transaction hash.`);
}

async function handlePayment(chatId, txHash) {
    bot.sendMessage(chatId, 'Verifying transaction...');
    
    try {
        // Check if transaction hash exists in MongoDB
        const existingTx = await db.collection('users').findOne({ txHash });
        if (existingTx) {
            bot.sendMessage(chatId, 'This transaction hash has already been used. Please send a new payment and provide the new transaction hash.');
            return;
        }
        
        // Check if the transaction hash is valid
        if (!/^0x([A-Fa-f0-9]{64})$/.test(txHash)) {
            bot.sendMessage(chatId, 'Invalid transaction hash format. Please provide a valid Ethereum transaction hash.');
            return;
        }

        let receipt, tx;
        try {
            receipt = await web3.eth.getTransactionReceipt(txHash);
            tx = await web3.eth.getTransaction(txHash);
        } catch (error) {
            if (error.message.includes('Transaction not found')) {
                bot.sendMessage(chatId, 'Transaction not found. Please check the transaction hash and try again. If you just sent the transaction, please wait a few minutes and try again.');
                return;
            }
            throw error;
        }

        if (!receipt || !tx) {
            bot.sendMessage(chatId, 'Unable to verify the transaction. Please check the transaction hash and try again later.');
            return;
        }

        if (receipt.status) {
            const value = Web3.utils.fromWei(tx.value, 'ether');
            
            if (tx.to.toLowerCase() === PAYMENT_ADDRESS.toLowerCase() && parseFloat(value) === 0.003) {
                // Save the user data and transaction to MongoDB
                await db.collection('users').insertOne({
                    chatId,
                    ...userState[chatId],
                    txHash,
                    transactionApproved: true,
                    timestamp: new Date()
                });
                
                bot.sendMessage(chatId, 'Congratulations! Your payment of exactly 0.003 ETH has been verified and your enrollment is complete.', {
                    reply_markup: {
                        keyboard: [["Transaction Approved"]],
                        resize_keyboard: true
                    }
                });
                delete userState[chatId];  // Clear user state
            } else if (tx.to.toLowerCase() !== PAYMENT_ADDRESS.toLowerCase()) {
                bot.sendMessage(chatId, 'The transaction was not sent to the correct address. Please send the payment to the provided address and submit the correct transaction hash.');
            } else {
                bot.sendMessage(chatId, 'The transaction amount is not exactly 0.003 ETH. Please send the correct amount and provide the new transaction hash.');
            }
        } else {
            bot.sendMessage(chatId, 'The transaction failed. Please check the transaction status and try again with a successful transaction.');
        }
    } catch (error) {
        console.error('Error verifying transaction:', error);
        bot.sendMessage(chatId, 'An error occurred while verifying the transaction. Please try again later.');
    }
}

// Main execution
async function main() {
    await connectToMongoDB();
    console.log('Bot is running on Ethereum mainnet...');
}

main().catch(console.error);